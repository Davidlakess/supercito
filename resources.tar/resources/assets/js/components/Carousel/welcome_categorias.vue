<template>	
<div class="slider">
<!-- parte inferior -->
</div>
</template>

</style>