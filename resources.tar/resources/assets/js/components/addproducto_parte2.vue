<template>
  <b-row align-h="center">
      <b-col cols="12" lg="6" class="title-head" style="margin-bottom: 25px;">
        <span>
        Cantidad para vender    
        </span>  
        <b-form-input placeholder="Cantidad disponible"></b-form-input>
      </b-col>
      <b-col cols="12" lg="6" class="title-head">
        <span>
        Precio producto <i class="fa fa-dollar-sign"></i>   
        </span>  
        <b-form-input placeholder="Cual es el Precio?"></b-form-input>
        <small class="s-small">.</small>
      </b-col>
     </b-col>
      <b-col cols="12" >
        <button type="submit" class="btns btns-default ">Guardar</button>
      </b-col>
    </b-row>
</template>
