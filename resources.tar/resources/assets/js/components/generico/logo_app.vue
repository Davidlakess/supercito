<template>
	<div  style="font-weight: 600;border: 3px solid #fff;border-radius: 50px;padding: 8px 7px 8px 7px;">
		<span>&lt;MyNegocioLocal&gt;</span>
	</div>
</template>
<script type="text/javascript">
	
	export default{
	}
</script>