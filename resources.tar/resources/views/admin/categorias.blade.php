@extends('admin.dashboard')

@section('content')
<categorias></categorias>
@endsection