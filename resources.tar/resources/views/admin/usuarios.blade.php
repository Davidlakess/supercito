@extends('admin.dashboard')

@section('content')
<usuarios></usuarios>
@endsection