@extends('admin.dashboard')

@section('content')
<ventas></ventas>
@endsection