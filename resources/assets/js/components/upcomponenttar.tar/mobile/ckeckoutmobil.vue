<template>
	<div>	
	<b-card no-body class="overflow-hidden" >

			<div style="padding: 15px;text-align: center;background-color: #ed4646;color: #fff;">
			   Opciones de envio a
			</div>
		<b-card-body>	
			<b-container style="padding: 15px;">
          		<div v-if="domicilio_si" style="padding: 15px;background-color: #f1e8e89c">
          			<div style="font-weight: 600;font-size: 16px;"><span >Domicilio</span></div>	
	          			<div class="normal-direccion" style="margin-top: 10px;">
	          				<span>
			                Calle: {{direccion.calle}} - numero #{{direccion.numero_e}} -interior #{{direccion.numero_i}} -entre {{direccion.calle_1}} - y {{direccion.calle_2}} - {{direccion.name}},
				  	 		Michoacán - +{{direccion.telefono}} 
			            	</span>
	          			</div>
				     	<div  class="normal-direccion" style="font-weight: 400;margin-top: 6px;">
				     		<b-button variant="link" class="m-1"
				     		 style="padding: 0;margin: 0 auto !important;" >Editar o elegir otro</b-button>
				     	</div>
          		</div>
          	
          			 <div v-else>
					  <b-button v-b-modal.modal-1>Registrar domicilio</b-button>

					  <b-modal id="modal-1" hide-footer title="Registrar Domicilio">
					    
					          <registrodomicilio :mt="true"></registrodomicilio> 
					  </b-modal>
					</div>
          		
          	</b-container>
          	<b-container style="padding: 15px;">
	          <div style="padding: 15px;border-radius: 10px;border: 1px solid #e1dddd;">

	          	<div class="decorate-pro" v-for="item in items">
					<b-col cols="3"  sm="1" lg="1" style="padding: 0;">
						<figure class="card card-product"  style=" border: none;">
				      <div> 
				         <b-img  style="height: 65px;" :src="'/uploads/'+item.img"></b-img>
				      </div>
				    </figure>
					</b-col>
				  	<b-col style="margin:0;padding: 0;"  class="card-item"> 
				 		<div><span>{{item.name}}</span></div>
				 		<div><span>Cantidad: {{item.cantidad}}</span></div>
			 			<div><span>$ {{item.precio}} c/u</span></div>
				 	</b-col>
				</div>

			</div>
			</b-container>
   		</b-card-body>
	</b-card>
              <div class="sticky" >
                <div style="font-size: 18px;font-weight: 400;display: grid; margin-bottom: 15px;">
                  <span>Costo de Envio: $ {{envio}}</span>
                </div>
                <div>

			        <form method="post" ref="paymet" action="/checkout/paymet">
			        	<!-- <slot></slot> -->
			        		<input type="hidden" name="id_carrito" v-model="id_carrito">
			        		<input type="hidden" name="id_localidad" v-model="id_localidad">
			        </form>

                	<b-button @click="domicilioexiste()" variant="outline-primary btn-block" 
                	>Continuar</b-button>
                </div>
              </div>  

	</div>	

</template>
<script>	
// import $ from 'jquery';

export default {
    props:['precioenvio','adress','propina','items','idcarrito'],  
    data(){
      return {
      	domicilio_si:true,
      	direccion:{},
      	id_carrito:this.idcarrito,
      	id_localidad:0,
      	envio:0,
      }
    },
    mounted() {
    	this.direccion=this.adress;
    	this.verificardomicilio();
    	this.envio=this.precioenvio;
    },
     created() {

      eventBus.$on('adddomicilio', (data) => {
        	this.domicilio_si=true;
        	this.direccion=data;
        	this.id_localidad=data.id_localidad;
      	})

    	eventBus.$on('setenvio', (envio) => {    
          this.envio=envio; 
	    });

      },
    methods: {
    	domicilioexiste(){
    		if(!this.domicilio_si){

	    		swal.fire(
	                '¡Agrega el Domicilio de Envio!',
	                '',
	                'info'
	             )

    		}else{


                Vue.nextTick().then(() =>{ 
                    this.$refs.paymet.submit();
                })     

    		}
    		console.log('hola prro')
    	},
		verificardomicilio() {
	      if(this.adress==0){
	      	this.domicilio_si=false;
	      }else{
	      	this.id_localidad=this.adres.id_localidad;
	      }
		},
	}

}
</script>
