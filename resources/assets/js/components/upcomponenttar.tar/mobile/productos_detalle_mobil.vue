<template>	
<div>	
	<b-card style="border:0;" class="c">
          <b-col md="12" lg="12" style="padding: 15px;">
            <div style="display: flex; flex-direction: column;"> 
              <span class="target-p" >Nuevo</span>  
                <span   class="titulo-p">
                  {{producto.name}}
                </span>
	                <ul class="opinion-p">
	                  <i class="fa fa-star text-danger" v-for="a in 4"></i>
	                  <i class="fa fa-star-half text-danger"></i>  
	                </ul>   
      		</div>
		   </b-col>

           <b-col md="12" xl="12">  
            <h6><b-badge>1/{{getsizeimgs()}}</b-badge></h6>                
                    <figure    @click="index = 0">
                        <div class="img-wrap"> 
                           <img :src="getimgs()[0]" class="img-mobil">
                        </div>
                    </figure>

            </b-col>
            <!-- {{producto}}	 -->
      <CoolLightBox 
      :items="getimgs()" 
      :index="index"
      @close="index = null">
    </CoolLightBox>

        </b-card>
      <b-card class="c">
        	<div style="display: flex; flex-direction: column; padding: 16px;"> 
	        
	         	<span>
                  Color: <span style="font-weight:600;">Blanco</span>
                </span>
			
             	<span  class="precio-p">
                  ${{producto.precio}}
                </span>
				
				<span class="estatus-p">
                  Disponible en Stock
                </span>
                
                <span class="estatus-p" >
                  Cantidad: <span>1 Unidad</span>
                </span>
        	</div>

        	<b-col md="12" lg="12" >
	            <div class="btn-carrito-p">
	              <btn-addcarrito :block="true" id="12" :logeado="logeado"> </btn-addcarrito>
	            </div>
          	</b-col>
          	 <b-col md="12" lg="12" style="margin-top: 20px;" >

           <ul class="list-group list-group-flush" >
         <li class="list-group-item" >
            <span style="font-weight:400; font-size: 18px;">Mas productos de Abarrotes</span>
         </li>
       <li class="list-group-item" >
        <ul class="list-group list-group-flush">
            <li class="list-group-item" v-for="e in extras">
                <b-row align-h="justify" class="poner-borde">                
            <b-col  col="6" class="p-0">
              <div class="img-wrap-m"> 
                <a :href="'/detalle/'+e.id">
                <img :src="'/uploads/'+e.img">
              </a>
            </div>
            </b-col>
            <b-col col="6" class="p-0">
                <b-col cols="12" class="p-0" style="display: flex; flex-direction: column;" >
                    <span class="name-producto">{{e.name}}</span>
                    <!-- <small>Vendido por </small> -->
                    <span style="font-size: 24px; margin-top: 10px;">${{e.precio}}</span>
                </b-col>
            </b-col>
                </b-row>
            </li>
        </ul>
	    </li>
	    <li class="list-group-item" >
	     <a href="#"> Ver mas</a>
	     </li>
	    </ul>
   	</b-col>
	   	<div style="display: flex; flex-direction: column; padding: 16px;">     
	       <div style="margin-bottom: 20px;font-size: 25px;">
	          <span>Informacion del Producto.</span>
	        </div>
	      <b-table
	      :items="características"
	      thead-tr-class="d-none"
	      :striped="true"
	      :bordered="true"
	      :fields="fields"
	    ></b-table>
	  
		<div style=" padding: 40px 16px;font-size: 20px;font-weight: 400;">
	        <span style="margin-bottom: 24px;">Descripcion</span>
	        <p class="content-descripcion-m">{{producto.des}}</p>
	    </div>
	</div>
  </b-card>
</div>	

</template>
 
<script>
 
import CoolLightBox from 'vue-cool-lightbox'
import 'vue-cool-lightbox/dist/vue-cool-lightbox.min.css'
 
  export default {
components: {
    CoolLightBox,
  },
props:['características','logeado','producto','extras'],
    data() {
      return {
      // items: [
      //   {
      //     title: '',
      //     description: "",
      //     thumb: 'https://cosmos-images2.imgix.net/file/spina/photo/20565/191010_nature.jpg?ixlib=rails-2.1.4&auto=format&ch=Width%2CDPR&fit=max&w=835',
      //     src: 'https://http2.mlstatic.com/D_NQ_NP_855802-MLM43825178339_102020-O.webp',
      //   },
      // ],
      index: null,
      fields: ['clave', 'valor'],
      }
    },
    mounted(){
        this.getimgs();
    },
    methods:{
        getimgs(){
           var img= this.producto.imgs.split(',');
           var images=[];
          for (var i =0; i< img.length ;i++ ) {
              images[i]='/uploads/'+img[i];
          }

          return  images;
        },
        getsizeimgs(){
           var img= this.producto.imgs.split(',');
           return img.length
        }
    }
}
</script>
<style>	
.content-descripcion-m{
font-weight: 400;
font-size: 16px;
word-break: break-word;
}
.c .card-body{
	padding:0;
}
.titulo-p{
 font-size: 16px;
font-weight: 400;
margin-bottom: 10px;
margin-top: 5px;
  }
  .precio-p{
    font-size: 36px;
    font-weight: 300;
    text-align: justify;
  }
  .estatus-p{
    font-size: 17px;
    color: #656565;
    padding-bottom: 10px;
  }
  .opinion-p{
    font-size: 11px;
    padding: 10px;
    padding: 0;
    margin: 0;
    color: #cdcde0;
  }
  .opinion-p i{
    margin-right: 3px;
  }


.img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 300px;
    text-align: center; }
    .img-wrap img {
      max-height: 100%;
      max-width: 100%;
      object-fit: cover; 
     padding: 16px;
  }
      
     .img-wrap-m {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 145px;
    text-align: center; }
  
  .img-wrap-m img {
      max-height: 100%;
      max-width: 100%;
      object-fit: cover; 
  }
  
</style>