<template>	
  <div> 
 <b-carousel
          id="carousel-1"
          :interval="5000"
          controls
          indicators
          background="#ababab"
          img-width="360"
          img-height="250"
          style="text-shadow: 1px 1px 2px #333; margin:0; padding: 0;"
        >
          <!-- Text slides with image -->
        <b-carousel-slide

          img-src="https://http2.mlstatic.com/storage/splinter-admin/1585678167888-home-slider_desktop_heineken.jpg"
          >

        </b-carousel-slide>
        <b-carousel-slide 
          img-src="https://http2.mlstatic.com/storage/splinter-admin/1585070690402-home-slider_desktop.jpg">
        </b-carousel-slide>
        
<!--         <b-carousel-slide>
          <template v-slot:img>
              <img
                class="d-block img-fluid w-100"
                height="480"
                src="https://http2.mlstatic.com/storage/splinter-admin/1585016488599-home-slider_desktop.jpg"
                alt="image slot"
              >
          </template>
        </b-carousel-slide>
 -->
      </b-carousel>
<div  style="margin: 20px 14px;">   
 <ul class="list-group list-group-flush" >
         <li class="list-group-item" >
            <span style="font-weight: bold; font-size: 17px;"> Produuctos de Abarrote</span>
         </li>
        <li class="list-group-item" >
        <ul class="list-group list-group-flush">
            <li class="list-group-item" v-for="pro in productos">
                <b-row align-h="justify" class="poner-borde">                
            <b-col  col="6" class="p-0">
              <div class="img-wrap"> 
                <a  :href="'/detalle/'+pro.id">
                <img :src="'/uploads/'+pro.img">
              </a>
            </div>
            </b-col>
            <b-col col="6" class="p-0">
                <b-col cols="12" class="p-0" style="display: flex; flex-direction: column;">
                    <span class="name-producto">{{pro.name}}</span>
                    <!-- <small>Vendido por </small> -->
                    <span style="font-size: 19px; margin-top: 10px;">${{pro.precio}}</span>
                </b-col>
            </b-col>
                </b-row>
            </li>
        </ul>
    </li>


    <li class="list-group-item" >
     <a href="#"> Ver mas</a>
     </li>
    </ul>
     <b-col md="12" style="padding: 0;">
        <div class="super-titulo" style="padding-left: 15px;"><span>Categorias:</span></div>
    
    <coleccion-cetgoria 
    :titulo="collection[0].name"
    etiqueta="Descubre"
    :img="collection[0].img"
    :pro="collection[0].items"
    :logeado="logeado"
    :head="false"
    ></coleccion-cetgoria>
    </b-col>
</div>
<div class="super-titulo" style="padding-left: 15px;"><span>Productos Nuevos..</span></div>
<div class="carousel-h">
  <div  v-for="pro in productos">
    
            <li class="list-group-item">
                <b-row align-h="justify" class="poner-borde">                
            <b-col  col="6" class="p-0">
              <div class="img-wrap"> 

                <a :href="'/detalle/'+pro.id">
                <img :src="'/uploads/'+pro.img">
              </a>
            </div>
            </b-col>
            <b-col col="6" class="p-0">
                <b-col cols="12" class="p-0" style="display: flex; flex-direction: column;padding: 1px;">
                    <span class="name-producto">{{pro.name}}</span>
                    <!-- <small>Vendido por </small> -->
                    <span style="font-size: 19px; margin-top: 10px;">{{pro.precio}}</span>
                </b-col>
            </b-col>
                </b-row>
            </li>
  </div>
</div>

<ul class="list-group list-group-flush" >
         <li class="list-group-item" style="background-color: #fff0 !important;">
 <div id="wrapper">
     <ul>
        <li v-for="item in categorias">
          <a :href="'#'+item.id">
            <i class="icon-list-alt">
            </i>
            <div style="text-transform: capitalize;">
              {{item.name}}
            </div>
          </a>
        </li>
      </ul>
    </div>
</li>
</ul>
</div>
</template>
<script>
    import coleccion_categoria  from '../categorias/coleccion_categoria.vue'
	export default {
	props:['productos','productosnuevos','logeado','categorias','collection'],
        components: {
                'coleccion-cetgoria':coleccion_categoria
        },
	data(){
			return {
				pro:[],
				mdruta:"/middlecarrito",
				// ismobil:false,
			}
		},
		created() {
			
		},
		mounted (){
			

		},
	computed:{
	},		
	methods:{
		 
	}
}
</script>
<style>	
html {

    overflow-x: hidden;
}
.text-gray {
    color: #aaa
}

.imgitem {
    height: 170px;
    width: 140px
}


/*img*/
 .img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 102px;
    text-align: center; }
  
  .img-wrap img {
      max-height: 100%;
      max-width: 100%;
      object-fit: cover; 
  }
      
.name-producto{
    margin: 0;padding: 0;
    position: static;
    font-size: 14px;
    font-weight: 400;
    color: #424242;
    line-height: 18px;
    max-height: none;
    /*word-break: break-all;*/
}

.carousel-h img {
    max-width: 100%;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.carousel img {
    width: 360px !important;
    height: 163px !important;
}

.carousel-h > div {
    flex: 0 0 auto;
max-width: 185px;
height: 100px;
scroll-snap-align: start;
/*    flex: 0 0 auto;
    max-width: 320px;height: 100%;
    scroll-snap-align: start;*/
}

.carousel-h{
/*  display: flex;
  flex-wrap: nowrap;

  width: 100%;
  max-width: 320px;
  height: 200px;
  overflow: scroll;

  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;*/

  display: inline-flex;
flex-wrap: nowrap;
width: 100%;
/*max-width: 320px;*/
height: 135px;
overflow: scroll;
scroll-snap-type: x mandatory;
scroll-behavior: smooth;
}



  
  
body #wrapper {
  width: 100%;
  height: 69%;
  margin-top: 20px;

}

body #wrapper ul {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 auto;
  padding: 0;
  height: 118px;
  /*background-color: #fff;*/
  font-size: 0px;
}


body #wrapper ul li {
 display: inline-block;
float: left;
width: 50%;
-moz-transition: all 0.1s;
-o-transition: all 0.1s;
-webkit-transition: all 0.1s;
transition: all 0.1s;
text-align: center;
-moz-box-sizing: border-box;
-webkit-box-sizing: border-box;
box-sizing: border-box;
text-shadow: 0px 1px 3px white;
border-right: thin solid lightgray;
border-bottom: thin solid lightgray;
background-color: white;
height: 141px;
}
body #wrapper ul li:last-child {
  border-right: none;
}

body #wrapper ul li:hover {
  /*background: #e6e6e6;*/
  /*width: 33.33333%;*/
    /*background-color: #3483fa;*/
  /*color: #fff;*/
  /*-moz-box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);
  box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);*/
}

body #wrapper ul li a:hover {
  /*background: #e6e6e6;*/
  /*width: 33.33333%;*/
   background-color: #3483fa;
   color: #fff !important;

/*  -moz-box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);
  box-shadow: inset 10px 10px 10px -10px rgba(0, 0, 0, 0.3), inset -10px 10px 10px -10px rgba(0, 0, 0, 0.3);*/
}


body #wrapper ul li a {
  display: flex;
-moz-box-sizing: border-box;
-webkit-box-sizing: border-box;
box-sizing: border-box;
text-decoration: none;
font-size: 38px;
outline: 1px solid #eae6e6;
padding: 50px;
flex-direction: column;
height: 100%;
}
body #wrapper ul li a:visited {
  color: gray;
}
body #wrapper ul li div {
  margin-top: 5px;
  font-weight: 600;
  font-size: 13px;
}
</style>